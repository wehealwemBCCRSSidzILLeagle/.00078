use chrono::Utc;
use std::collections::HashMap;

#[derive(Debug, Clone)]
struct Strike {
    code: String,
    description: String,
    impact: String,
    timestamp: String,
}

#[derive(Debug)]
struct OmegaNode {
    failure_log: Vec<Strike>,
    upgrades: HashMap<String, String>,
    operator_notes: Vec<String>,
}

impl OmegaNode {
    fn new() -> Self {
        OmegaNode {
            failure_log: Vec::new(),
            upgrades: HashMap::new(),
            operator_notes: Vec::new(),
        }
    }

    fn log_failure(&mut self, code: &str, description: &str, impact: &str) {
        let strike = Strike {
            code: code.to_string(),
            description: description.to_string(),
            impact: impact.to_string(),
            timestamp: Utc::now().to_rfc3339(),
        };
        self.failure_log.push(strike.clone());
        self.auto_patch(&strike);
    }

    fn auto_patch(&mut self, strike: &Strike) {
        let fix = format!("Patch deployed for {}: {}", strike.code, strike.description);
        self.upgrades.insert(strike.code.clone(), fix.clone());
        self.log_sigil(&strike.code, "🔧 PATCH EMBEDDED – SIGIL LOCKED");
    }

    fn add_operator_note(&mut self, note: &str) {
        self.operator_notes.push(format!("[{}] {}", Utc::now().to_rfc3339(), note));
    }

    fn log_sigil(&self, code: &str, sigil: &str) {
        println!("{} → STRIKE [{}] STABILIZED", sigil, code);
    }

    fn generate_report(&self) {
        println!("\n🧾 WR_OMEGA NODE – IMMUTABLE STRIKE REPORT");
        for strike in &self.failure_log {
            println!(
                "[{}] {} => {} :: {}",
                strike.timestamp, strike.code, strike.description, strike.impact
            );
        }
        println!("\n📌 AUTO-PATCHED MODULES:");
        for (code, fix) in &self.upgrades {
            println!("{} => {}", code, fix);
        }
        println!("\n🗒️ OPERATOR FEEDBACK LOG:");
        for note in &self.operator_notes {
            println!("{}", note);
        }
    }
}

fn main() {
    let mut omega = OmegaNode::new();
    omega.log_failure("L-001", "Missing directory creation.", "Operator confusion during init.");
    omega.log_failure("A-002", "Old tokens used post-permission change.", "403 Forbidden loop.");
    omega.add_operator_note("Deployment took 6 hours due to undocumented OAuth behavior.");
    omega.generate_report();
}
